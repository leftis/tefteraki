/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
/**
 * @fileOverview Defines the {@link CKEDITOR.dtd} object, which holds the DTD
 *		mapping for XHTML 1.0 Transitional. This file was automatically
 *		generated from the file: xhtml1-transitional.dtd.
 */
/**
 * @namespace Holds and object representation of the HTML DTD to be used by the
 * editor in its internal operations.<br />
 * <br />
 * Each element in the DTD is represented by a property in this object. Each
 * property contains the list of elements that can be contained by the element.
 * Text is represented by the "#" property.<br />
 * <br />
 * Several special grouping properties are also available. Their names start
 * with the "$" character.
 * @example
 * // Check if "div" can be contained in a "p" element.
 * alert( !!CKEDITOR.dtd[ 'p' ][ 'div' ] );  "false"
 * @example
 * // Check if "p" can be contained in a "div" element.
 * alert( !!CKEDITOR.dtd[ 'div' ][ 'p' ] );  "true"
 * @example
 * // Check if "p" is a block element.
 * alert( !!CKEDITOR.dtd.$block[ 'p' ] );  "true"
 */
CKEDITOR.dtd=function(){var e=CKEDITOR.tools.extend,t={isindex:1,fieldset:1},n={input:1,button:1,select:1,textarea:1,label:1},r=e({a:1},n),i=e({iframe:1},r),s={hr:1,ul:1,menu:1,div:1,section:1,header:1,footer:1,nav:1,article:1,aside:1,figure:1,dialog:1,hgroup:1,mark:1,time:1,meter:1,command:1,keygen:1,output:1,progress:1,audio:1,video:1,details:1,datagrid:1,datalist:1,blockquote:1,noscript:1,table:1,center:1,address:1,dir:1,pre:1,h5:1,dl:1,h4:1,noframes:1,h6:1,ol:1,h1:1,h3:1,h2:1},o={ins:1,del:1,script:1,style:1},u=e({b:1,acronym:1,bdo:1,"var":1,"#":1,abbr:1,code:1,br:1,i:1,cite:1,kbd:1,u:1,strike:1,s:1,tt:1,strong:1,q:1,samp:1,em:1,dfn:1,span:1,wbr:1},o),a=e({sub:1,img:1,object:1,sup:1,basefont:1,map:1,applet:1,font:1,big:1,small:1,mark:1},u),f=e({p:1},a),l=e({iframe:1},a,n),c={img:1,noscript:1,br:1,kbd:1,center:1,button:1,basefont:1,h5:1,h4:1,samp:1,h6:1,ol:1,h1:1,h3:1,h2:1,form:1,font:1,"#":1,select:1,menu:1,ins:1,abbr:1,label:1,code:1,table:1,script:1,cite:1,input:1,iframe:1,strong:1,textarea:1,noframes:1,big:1,small:1,span:1,hr:1,sub:1,bdo:1,"var":1,div:1,section:1,header:1,footer:1,nav:1,article:1,aside:1,figure:1,dialog:1,hgroup:1,mark:1,time:1,meter:1,menu:1,command:1,keygen:1,output:1,progress:1,audio:1,video:1,details:1,datagrid:1,datalist:1,object:1,sup:1,strike:1,dir:1,map:1,dl:1,applet:1,del:1,isindex:1,fieldset:1,ul:1,b:1,acronym:1,a:1,blockquote:1,i:1,u:1,s:1,tt:1,address:1,q:1,pre:1,p:1,em:1,dfn:1},h=e({a:1},l),p={tr:1},d={"#":1},v=e({param:1},c),m=e({form:1},t,i,s,f),g={li:1},y={style:1,script:1},b={base:1,link:1,meta:1,title:1},w=e(b,y),E={head:1,body:1},S={html:1},x={address:1,blockquote:1,center:1,dir:1,div:1,section:1,header:1,footer:1,nav:1,article:1,aside:1,figure:1,dialog:1,hgroup:1,time:1,meter:1,menu:1,command:1,keygen:1,output:1,progress:1,audio:1,video:1,details:1,datagrid:1,datalist:1,dl:1,fieldset:1,form:1,h1:1,h2:1,h3:1,h4:1,h5:1,h6:1,hr:1,isindex:1,noframes:1,ol:1,p:1,pre:1,table:1,ul:1};return{$nonBodyContent:e(S,E,b),$block:x,$blockLimit:{body:1,div:1,section:1,header:1,footer:1,nav:1,article:1,aside:1,figure:1,dialog:1,hgroup:1,time:1,meter:1,menu:1,command:1,keygen:1,output:1,progress:1,audio:1,video:1,details:1,datagrid:1,datalist:1,td:1,th:1,caption:1,form:1},$inline:h,$body:e({script:1,style:1},x),$cdata:{script:1,style:1},$empty:{area:1,base:1,br:1,col:1,hr:1,img:1,input:1,link:1,meta:1,param:1,wbr:1},$listItem:{dd:1,dt:1,li:1},$list:{ul:1,ol:1,dl:1},$nonEditable:{applet:1,button:1,embed:1,iframe:1,map:1,object:1,option:1,script:1,textarea:1,param:1,audio:1,video:1},$captionBlock:{caption:1,legend:1},$removeEmpty:{abbr:1,acronym:1,address:1,b:1,bdo:1,big:1,cite:1,code:1,del:1,dfn:1,em:1,font:1,i:1,ins:1,label:1,kbd:1,q:1,s:1,samp:1,small:1,span:1,strike:1,strong:1,sub:1,sup:1,tt:1,u:1,"var":1,mark:1},$tabIndex:{a:1,area:1,button:1,input:1,object:1,select:1,textarea:1},$tableContent:{caption:1,col:1,colgroup:1,tbody:1,td:1,tfoot:1,th:1,thead:1,tr:1},html:E,head:w,style:d,script:d,body:m,base:{},link:{},meta:{},title:d,col:{},tr:{td:1,th:1},img:{},colgroup:{col:1},noscript:m,td:m,br:{},wbr:{},th:m,center:m,kbd:h,button:e(f,s),basefont:{},h5:h,h4:h,samp:h,h6:h,ol:g,h1:h,h3:h,option:d,h2:h,form:e(t,i,s,f),select:{optgroup:1,option:1},font:h,ins:h,menu:g,abbr:h,label:h,table:{thead:1,col:1,tbody:1,tr:1,colgroup:1,caption:1,tfoot:1},code:h,tfoot:p,cite:h,li:m,input:{},iframe:m,strong:h,textarea:d,noframes:m,big:h,small:h,span:h,hr:{},dt:h,sub:h,optgroup:{option:1},param:{},bdo:h,"var":h,div:m,object:v,sup:h,dd:m,strike:h,area:{},dir:g,map:e({area:1,form:1,p:1},t,o,s),applet:v,dl:{dt:1,dd:1},del:h,isindex:{},fieldset:e({legend:1},c),thead:p,ul:g,acronym:h,b:h,a:l,blockquote:m,caption:h,i:h,u:h,tbody:p,s:h,address:e(i,f),tt:h,legend:h,q:h,pre:e(u,r),p:h,em:h,dfn:h,section:m,header:m,footer:m,nav:m,article:m,aside:m,figure:m,dialog:m,hgroup:m,mark:h,time:h,meter:h,menu:h,command:h,keygen:h,output:h,progress:v,audio:v,video:v,details:v,datagrid:v,datalist:v}}();